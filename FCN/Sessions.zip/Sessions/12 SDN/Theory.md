5 → 100 Mbps
5e → 1 Gbps
6 → 10 Gbps (short distance)
6a → 10 Gbps (full distance)


Software Defined Networking (SDN)
```
Software Defined Networking (SDN) is a way of managing a network using software instead of manually configuring each device

A) One central controller (software) decides how traffic should flow

B) Network devices (like switches) just follow instructions

C) It makes the network easier to control, flexible, and automated

Think of it like a remote control system:
```

# Need of SDN

```
Traditional networks are hard to manage and slow to change because each device must be configured separately.

SDN helps by:

1] Controlling everything from one place (central controller)

2] Using software to automate tasks instead of manual setup

3] Making networks flexible and quick to adapt
```


# SDN Component

* **SDN Applications:** Define what the network should do (policies and rules)
* **SDN Controller:** Decides how the network should operate (central brain)
* **SDN Devices:** Carry out the instructions by forwarding data

👉 **In short:**
**Apps tell → Controller decides → Devices execute**

![SDN Architecture](https://media.geeksforgeeks.org/wp-content/uploads/20260113125547470176/sdn_architecture.webp)


# SDN Architecture
```
SDN architecture is organized into three logical layers

1. Application Layer
2. Control Layer
3. Infrastructure Layer (Data Plane)


1. **Application Layer**

Contains network applications such as traffic management, security, and monitoring tools.

Allows administrators to define network policies and requirements.

Communicates with the SDN controller through northbound APIs.

2. **Control Layer**
SDN Controller Brain of Network
Translates application requirements into forwarding rules.

3. **Infrastructure Layer (Data Plane)**

Consists of physical or virtual switches and routers. Forwards packets based on rules received from the controller. Does not make independent decisions, ensuring simple and efficient forwarding.

👉 In short:
**Apps decide → Controller thinks → Devices act.**
```

| **Feature**         | **Control Plane**                         | **Data Plane**                            |
| ------------------- | ----------------------------------------- | ----------------------------------------- |
| **Purpose**         | Handles decision-making and control logic | Handles actual forwarding of data packets |
| **Function**        | Determines routes and network policies    | Forwards packets based on rules           |
| **Location (SDN)**  | Centralized in SDN controller             | In switches and routers                   |
| **Decision Making** | Makes decisions                           | Follows instructions only                 |
| **Network View**    | Global view of entire network             | Local view (device-level)                 |
| **Programmability** | Highly programmable                       | Limited programmability                   |
| **Complexity**      | Complex                                   | Simple and fast                           |
| **Examples**        | SDN Controller, routing logic             | Switches, forwarding tables               |


```
In Software Defined Networking, APIs act as communication interfaces between different layers of the SDN architecture. 
1. Northbound APIs
2. Southbound APIs
```

# NorthBound APIs
```
Northbound APIs allow communication between the Application Layer and the SDN Controller. 

Enable network applications to define high-level policies, such as routing, load balancing, and security rules, without dealing with low-level network details. These APIs simplify network management and support automation by providing an abstract view of the network.

Example: REST APIs are commonly used as northbound interfaces to allow applications to interact with the SDN controller using standard web-based methods.

👉 **In short:**
**They allow apps to tell the network what to do in a simple way.**
```

# SouthBound APIs
```
2. Southbound APIs

Southbound APIs enable communication between the SDN Controller and the Infrastructure Layer (switches and routers). 

Allow  controller to install forwarding rules and manage packet flow in the data plane. Through southbound APIs, network devices follow instructions from the centralized controller instead of making independent decisions.

Example: OpenFlow is a widely used southbound protocol that allows the SDN controller to directly program flow tables in switches.
```


# Models of SDN Implementation

Different SDN Implementation models exist depending on how the control and network devices interact.

```
Open SDN → uses OpenFlow
API-Based SDN → uses REST/gRPC
Overlay SDN → virtual networks
Hybrid SDN → mix of traditional + SDN
```

# SDN vs Traditional Networking
Traditional Networking	Softw

Here’s your comparison in a clean table:

| 🔥 **Point**        | **Traditional Networking** | **Software-Defined Networking (SDN)**   |
| ------------------- | -------------------------- | --------------------------------------- |
| ⭐ Control Plane     | Combined with data plane   | **Separated & centralized**             |
| ⭐ Decision Making   | Devices decide + forward   | **Controller decides, devices forward** |
| ⭐ Management        | Manual (device-by-device)  | **Centralized & automated**             |
| ⭐ Configuration     | CLI (slow, error-prone)    | **APIs (fast, flexible)**               |
| ⭐ Scalability       | Limited                    | **Highly scalable**                     |
| 🔹 Network Behavior | Hardware-based (fixed)     | **Software-based (dynamic)**            |
| 🔹 Vendor Support   | Vendor-dependent           | **Vendor-neutral (multi-vendor)**       |
| 🔹 Fault Recovery   | Slow                       | **Fast via controller**                 |
| 🔸 Upgrades         | Hardware changes required  | **Software updates (cost-effective)**   |


👉 **In short:**
**Traditional = manual & rigid**
**SDN = automated & flexible**


## Advantages
- **Centralized control**
- **Automation**
- **Flexibility**
- **Cost efficient**
- **Fast innovation**

## Disadvantages
- **Single point of failure**
- **Security risks**
- **Controller bottleneck**
- **Complex migration**

## Applications
- **Data centers**
- **Cloud networking**
- **Traffic management**
- **Network virtualization**
- **Security systems**