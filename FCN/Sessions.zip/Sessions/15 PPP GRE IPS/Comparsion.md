| Feature         | PPP       | PPPoE            | MLPPP                      |
| --------------- | --------- | ---------------- | -------------------------- |
| Standard        | RFC 1661  | RFC 2516         | RFC 1990                   |
| Medium          | Serial    | Ethernet         | Multiple links             |
| Links           | Single    | Single (logical) | Multiple                   |
| Bandwidth       | Normal    | Normal           | High (aggregated)          |
| Authentication  | PAP, CHAP | PAP, CHAP        | PAP, CHAP                  |
| Special Feature | LCP + NCP | Discovery phase  | Fragmentation & sequencing |
| Usage           | Dial-up   | DSL broadband    | High-speed WAN             |


Last-Minute Revision Tricks
PPP = LCP + NCP + Auth
CHAP > PAP (security)
PPPoE = PPP + Ethernet
PADI → PADO → PADR → PADS
MLPPP = multiple links + sequencing



| Feature          | GRE             | IPsec                                |
| ---------------- | --------------- | ------------------------------------ |
| Purpose          | Tunneling       | Security                             |
| Encryption       | ❌ No            | ✅ Yes                                |
| Protocol support | Multi-protocol  | IP only                              |
| Security         | None            | Strong (encryption + authentication) |
| Typical use      | Routing tunnels | VPNs                                 |


Often, these two are combined:

GRE handles routing and multi-protocol traffic
IPsec adds encryption and security

👉 This setup is widely used in enterprise networks to create secure, flexible VPN tunnels.

Quick Analogy
GRE = A pipe that carries different types of data
IPsec = A lock and armor that protects the data inside the pipe

GRE is a tunneling protocol that wraps data packets inside another packet so they can travel between networks.

IPsec is a protocol suite that secures data by encrypting and protecting IP packets as they travel across a network.

GRE: “Send data through a tunnel”
IPsec: “Protect data with encryption”