# 1. Spanning Tree Protocol (STP)

> **Spanning Tree Protocol (STP)** is a Layer 2 network protocol used in Ethernet switches to prevent **network loops** in redundant network topologies.

> Standardized as **IEEE 802.1D**

---

# 2. Why STP is Needed

> In switched networks, redundant links are created for fault tolerance.

### Problems Without STP

* Broadcast storms
* MAC address table instability
* Multiple frame copies
* Network congestion and crashes

### Solution

> STP blocks redundant paths while keeping them available as backup links.

---

# 3. Basic Working of STP

> STP creates a **loop-free logical topology** by selecting one active path between switches.

## 3.1 STP Process

### 1. Elect a Root Bridge

> One switch becomes the central reference point.

* Lowest Bridge ID wins

---

### 2. Select Root Ports

> Each non-root switch selects the shortest path toward the Root Bridge.

---

### 3. Select Designated Ports

> One designated port is selected for each network segment.

---

### 4. Block Redundant Ports

> Extra ports are placed into blocking state to avoid loops.

---

# 4. Bridge ID (BID)

## Formula

[
\text{Bridge ID} = \text{Priority} + \text{MAC Address}
]

### Important Points

* Lower priority value is preferred
* If priorities are equal, lower MAC address wins

---

# 5. Priority Number in STP

## Default Priority

> **32768**

---

## Range

* 0 to 61440
* Increment of 4096

---

## Important Rule

> Lower priority value = Higher chance of becoming Root Bridge

### Example

* Priority **24576** → Higher priority than 32768
* Priority **4096** → Very high chance of becoming Root Bridge

---

## Root Bridge Selection Criteria

1. Lowest Bridge Priority
2. Lowest MAC Address

---

# 6. STP Port States

| Port State | Description                    |
| ---------- | ------------------------------ |
| Blocking   | Receives only BPDUs            |
| Listening  | Processes BPDUs, no forwarding |
| Learning   | Learns MAC addresses           |
| Forwarding | Sends and receives data        |
| Disabled   | Administratively down          |

---

# 7. BPDU (Bridge Protocol Data Unit)

> Switches exchange special frames called **BPDUs**.

## Purpose of BPDUs

* Elect Root Bridge
* Calculate shortest paths
* Detect topology changes

---

# 8. STP Path Cost

> STP selects the shortest path based on **path cost**.

### Rule

> Lower cost = Better path

---

## Typical STP Costs

| Speed    | Cost |
| -------- | ---- |
| 10 Mbps  | 100  |
| 100 Mbps | 19   |
| 1 Gbps   | 4    |
| 10 Gbps  | 2    |

---

# 9. Example of STP Operation

> Three switches are connected in a triangle topology.

### STP Actions

* Elects one Root Bridge
* Blocks one redundant link
* Allows loop-free traffic flow
* Reactivates blocked port if active link fails

---

# 10. Types of STP

| Protocol | Description          |
| -------- | -------------------- |
| STP      | Original IEEE 802.1D |
| RSTP     | Rapid STP            |
| MSTP     | Multiple STP         |
| PVST+    | Cisco Per-VLAN STP   |

---

# 11. Rapid Spanning Tree Protocol (RSTP)

> RSTP improves convergence time significantly.

## Features

* Faster recovery
* Reduced downtime
* Better performance

---

# 12. Advantages of STP

* Prevents switching loops
* Avoids broadcast storms
* Provides redundancy
* Improves network stability

---

# 13. Disadvantages of STP

* Some links remain unused
* Slow convergence in traditional STP
* Complex in large networks

---

# 14. Applications of STP

* Enterprise LANs
* Campus networks
* Data centers
* Redundant Ethernet environments

---

# 15. Conclusion

> Spanning Tree Protocol (STP) is an essential Layer 2 protocol that prevents network loops while maintaining redundancy and improving network reliability.
