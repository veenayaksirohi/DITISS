In Spanning Tree Protocol, the **priority number** is a value used to determine which switch becomes the **Root Bridge** in the network.

### Key Points

* The **default STP priority** is usually **32768**.
* The switch with the **lowest priority number** becomes the **Root Bridge**.
* If two switches have the same priority, the switch with the **lowest MAC address** wins.

### Priority Value Range

* Valid values: **0 to 61440**
* Must be in increments of **4096**

Examples:

* 0
* 4096
* 8192
* 12288
* …
* 61440

### Example

| Switch   | Priority | MAC Address | Result      |
| -------- | -------- | ----------- | ----------- |
| Switch A | 32768    | Higher MAC  | Not Root    |
| Switch B | 24576    | Lower MAC   | Root Bridge |

Because **24576 < 32768**, Switch B becomes the Root Bridge.

### Command Example (Cisco)

```bash
Switch(config)# spanning-tree vlan 1 priority 24576
```

This sets the STP priority for VLAN 1 to **24576**.
