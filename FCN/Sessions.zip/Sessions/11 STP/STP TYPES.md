| Short Form      | Full Form                                    | Standard          | Description                                              | Convergence Speed |
| --------------- | -------------------------------------------- | ----------------- | -------------------------------------------------------- | ----------------- |
| **STP**         | Spanning Tree Protocol                       | IEEE 802.1D       | Original protocol used to prevent network loops          | Slow (30–50 sec)  |
| **RSTP**        | Rapid Spanning Tree Protocol                 | IEEE 802.1w       | Improved STP with faster recovery                        | Fast (1–10 sec)   |
| **MSTP**        | Multiple Spanning Tree Protocol              | IEEE 802.1s       | Supports multiple spanning-tree instances for VLANs      | Fast              |
| **PVST**        | Per-VLAN Spanning Tree                       | Cisco Proprietary | Separate STP instance for each VLAN                      | Moderate          |
| **PVST+**       | Per-VLAN Spanning Tree Plus                  | Cisco Proprietary | Enhanced PVST compatible with IEEE STP                   | Moderate          |
| **Rapid PVST+** | Rapid Per-VLAN Spanning Tree Plus            | Cisco Proprietary | Combines RSTP speed with per-VLAN support                | Very Fast         |
| **SPB**         | Shortest Path Bridging                       | IEEE 802.1aq      | Uses shortest-path forwarding instead of traditional STP | Very Fast         |
| **TRILL**       | Transparent Interconnection of Lots of Links | IETF Standard     | Alternative to STP using routing concepts                | Very Fast         |
