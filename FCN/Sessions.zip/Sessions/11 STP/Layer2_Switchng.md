Layer 2 Switching

Layer 2 switching operates at the Data Link Layer of the OSI model.
A Layer 2 switch uses MAC addresses to forward frames between devices within the same LAN.

Layer 2 switching is the process of forwarding data frames using MAC addresses at the Data Link layer (Layer 2) of the OSI model.


How Layer 2 Switching Works

Functions of a Layer 2 Switch
Learning MAC addresses
Forwarding frames
Filtering frames
Flooding unknown frames

1. Frame Reception
A switch receives an Ethernet frame on one of its ports.
2. MAC Address Learning
The switch reads the source MAC address and stores it in its MAC address table (CAM table) along with the incoming port.
3. Forwarding Decision
The switch checks the destination MAC address:
If known → forwards frame only to the correct port
If unknown → floods frame to all ports except the source port
4. Communication
The destination device replies, allowing the switch to learn more MAC addresses.

Features of Layer 2 Switching

Uses MAC address table to send data
Reduces network collisions
Supports full-duplex communication
Provides faster LAN communication
Works within the same broadcast domain


| Switching Method  | How It Works                                  | Error Checking | Speed / Latency         | Reliability                  |
| ----------------- | --------------------------------------------- | -------------- | ----------------------- | ---------------------------- |
| Store-and-Forward | Receives the entire frame before forwarding   | Full CRC check | Slower (higher latency) | Most reliable                |
| Cut-Through       | Forwards frame as soon as destination is read | Minimal        | Fast (low latency)      | Less reliable                |
| Fragment-Free     | Reads first 64 bytes before forwarding        | Partial        | Moderate                | Balanced reliability & speed |



| Feature                | Hub        | Layer 2 Switch |
| ---------------------- | ---------- | -------------- |
| Intelligent forwarding | No         | Yes            |
| Uses MAC table         | No         | Yes            |
| Collision domains      | One shared | One per port   |
| Duplex                 | Half       | Full           |
| Efficiency             | Low        | High           |

