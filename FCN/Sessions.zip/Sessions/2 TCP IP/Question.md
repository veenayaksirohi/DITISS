# 📘 MCQs on Internet Protocol & TCP/IP Model

---

## 🔹 Section 1: Internet Protocol (IP)

1. **What does IP stand for?**
   A. Internet Process
   B. Internet Protocol ✅
   C. Internal Protocol
   D. Interface Protocol

2. **IP works at which layer of TCP/IP model?**
   A. Application
   B. Transport
   C. Internet ✅
   D. Network Access

3. **IP is a:**
   A. Connection-oriented protocol
   B. Connectionless protocol ✅
   C. Secure protocol
   D. Reliable protocol

4. **Which version uses 32-bit addressing?**
   A. IPv6
   B. IPv4 ✅
   C. IPv8
   D. None

5. **Which version uses 128-bit addressing?**
   A. IPv4
   B. IPv6 ✅
   C. IPv5
   D. IPv3

6. **IP provides:**
   A. Reliable delivery
   B. Guaranteed delivery
   C. Best-effort delivery ✅
   D. Ordered delivery

7. **A unit of data in IP is called:**
   A. Frame
   B. Segment
   C. Packet ✅
   D. Bit

8. **IP address identifies:**
   A. Network only
   B. Host only
   C. Both network and host ✅
   D. None

9. **Which protocol handles routing?**
   A. TCP
   B. UDP
   C. IP ✅
   D. HTTP

10. **IPv4 address example:**
    A. 2001:db8::1
    B. 192.168.1.1 ✅
    C. ABCD::1234
    D. 12345

---

## 🔹 Section 2: TCP/IP Model

11. **TCP/IP model has how many layers?**
    A. 3
    B. 4 ✅
    C. 5
    D. 7

12. **Which is the top layer?**
    A. Transport
    B. Internet
    C. Application ✅
    D. Network

13. **Which layer handles user interaction?**
    A. Application ✅
    B. Transport
    C. Internet
    D. Physical

14. **Which layer ensures end-to-end communication?**
    A. Internet
    B. Transport ✅
    C. Application
    D. Network

15. **Which layer deals with routing?**
    A. Transport
    B. Internet ✅
    C. Application
    D. Network

16. **Which layer includes Ethernet?**
    A. Application
    B. Transport
    C. Network Access ✅
    D. Internet

17. **HTTP belongs to:**
    A. Transport
    B. Internet
    C. Application ✅
    D. Network

18. **TCP belongs to:**
    A. Application
    B. Transport ✅
    C. Internet
    D. Network

19. **IP belongs to:**
    A. Transport
    B. Internet ✅
    C. Application
    D. Network

20. **DNS belongs to:**
    A. Application ✅
    B. Transport
    C. Internet
    D. Physical

---

## 🔹 Section 3: TCP (Transmission Control Protocol)

21. **TCP is:**
    A. Connectionless
    B. Connection-oriented ✅
    C. Stateless
    D. Fastest protocol

22. **TCP ensures:**
    A. No delivery
    B. Reliable delivery ✅
    C. No checking
    D. Fast delivery only

23. **TCP uses:**
    A. 2-way handshake
    B. 3-way handshake ✅
    C. 4-way handshake
    D. No handshake

24. **TCP provides:**
    A. Flow control ✅
    B. No control
    C. Only speed
    D. No error checking

25. **TCP is slower because:**
    A. No connection
    B. Reliability mechanisms ✅
    C. Less data
    D. No routing

26. **TCP data unit is:**
    A. Datagram
    B. Segment ✅
    C. Packet
    D. Frame

27. **TCP checks:**
    A. Errors ✅
    B. Speed
    C. Address
    D. Routing only

28. **TCP is used in:**
    A. Video streaming
    B. Email ✅
    C. Gaming
    D. DNS

29. **TCP guarantees:**
    A. No order
    B. Order of data ✅
    C. No delivery
    D. Fast delivery

30. **TCP acknowledgment is:**
    A. Optional
    B. Mandatory ✅
    C. Not used
    D. Rare

---

## 🔹 Section 4: UDP (User Datagram Protocol)

31. **UDP is:**
    A. Connection-oriented
    B. Connectionless ✅
    C. Reliable
    D. Secure

32. **UDP is faster because:**
    A. No reliability checks ✅
    B. More data
    C. Bigger packets
    D. More control

33. **UDP data unit is:**
    A. Segment
    B. Datagram ✅
    C. Packet
    D. Frame

34. **UDP provides:**
    A. Reliability
    B. No reliability ✅
    C. Full control
    D. Error recovery

35. **UDP is used in:**
    A. Email
    B. File transfer
    C. Streaming ✅
    D. Banking

36. **UDP supports:**
    A. Acknowledgment
    B. No acknowledgment ✅
    C. Flow control
    D. Congestion control

37. **UDP is best for:**
    A. Accuracy
    B. Speed ✅
    C. Security
    D. Storage

38. **UDP does not guarantee:**
    A. Speed
    B. Delivery ✅
    C. Transmission
    D. Sending

39. **UDP header is:**
    A. Large
    B. Small ✅
    C. Medium
    D. Complex

40. **UDP is suitable for:**
    A. Large files
    B. Real-time apps ✅
    C. Secure apps
    D. Banking

---

## 🔹 Section 5: TCP vs UDP

41. **Which is reliable?**
    A. UDP
    B. TCP ✅

42. **Which is faster?**
    A. TCP
    B. UDP ✅

43. **Which uses handshake?**
    A. TCP ✅
    B. UDP

44. **Which has low overhead?**
    A. TCP
    B. UDP ✅

45. **Which ensures order?**
    A. TCP ✅
    B. UDP

46. **Which is used in gaming?**
    A. TCP
    B. UDP ✅

47. **Which is used in HTTP?**
    A. TCP ✅
    B. UDP

48. **Which is connectionless?**
    A. TCP
    B. UDP ✅

49. **Which has congestion control?**
    A. TCP ✅
    B. UDP

50. **Which has no error recovery?**
    A. TCP
    B. UDP ✅

---

## 🔹 Section 6: Mixed Questions (51–100)

* IP stands for Internet Protocol ✅
* TCP stands for Transmission Control Protocol ✅
* UDP stands for User Datagram Protocol ✅
* TCP is reliable ✅
* UDP is unreliable ✅
* IPv6 uses 128-bit address ✅
* TCP uses handshake ✅
* UDP does not use handshake ✅
* TCP ensures delivery ✅
* UDP does not ensure delivery ✅
* TCP is slower ✅
* UDP is faster ✅
* TCP uses acknowledgment ✅
* UDP does not use acknowledgment ✅
* IP is connectionless ✅
* TCP works at transport layer ✅
* UDP works at transport layer ✅
* IP works at internet layer ✅
* Ethernet works at network access layer ✅
* HTTP works at application layer ✅
* DNS works at application layer ✅
* FTP works at application layer ✅
* TCP uses segments ✅
* UDP uses datagrams ✅
* IP uses packets ✅
* TCP ensures order ✅
* UDP does not ensure order ✅
* TCP has high overhead ✅
* UDP has low overhead ✅
* TCP is used in email ✅
* UDP is used in streaming ✅
* TCP supports congestion control ✅
* UDP does not support congestion control ✅
* IP provides routing ✅
* TCP provides reliability ✅
* UDP provides speed ✅
* TCP is connection-oriented ✅
* UDP is connectionless ✅
* IP address identifies host and network ✅
* TCP checks errors ✅
* UDP has minimal error checking ✅
* TCP retransmits lost data ✅
* UDP does not retransmit ✅
* TCP is used in banking apps ✅
* UDP is used in VoIP ✅
* TCP ensures data integrity ✅
* UDP sacrifices reliability for speed ✅
* TCP uses sliding window ✅
* UDP has no flow control ✅
* IP does not guarantee delivery ✅

---

## ✅ Final Tip

Focus on:

* Definitions
* Layer mapping
* TCP vs UDP differences

These are most asked in exams.

---
